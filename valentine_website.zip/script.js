
let page = 1;
const noResponses = [
    "Yes please konjo",
    "Please I’ll be sad",
    "Please Yene hule neger",
    "Please I’ll be sad"
];
function nextPage() {
    if (page === 1) {
        document.querySelector('h1').innerText = "Will you be my Valentine?";
        document.querySelector('button').remove();
        const yesButton = document.createElement('button');
        yesButton.innerText = "Yes";
        yesButton.onclick = showLove;
        const noButton = document.createElement('button');
        noButton.innerText = "No";
        noButton.onclick = noClicked;
        document.querySelector('.container').appendChild(yesButton);
        document.querySelector('.container').appendChild(noButton);
    }
    page++;
}
let noCount = 0;
function noClicked() {
    if (noCount < noResponses.length) {
        alert(noResponses[noCount]);
        noCount++;
    } else {
        alert("Please say yes 😢");
    }
}
function showLove() {
    document.querySelector('.container').innerHTML = `
        <h1>I love you so much Yene hule neger ke minim belay new mewdesh Yene tafachi you're everything I ever asked for, and I’m so grateful for you.</h1>
        <p>200 Reasons why I love you:</p>
        <ul>
            <li>1. Love for God</li>
            <li>2. Love for others</li>
            <li>3. Love for me</li>
            <li>...</li>
            <li>200. You're perfect in every possible way</li>
        </ul>
    `;
}
